const CACHE_NAME = 'voiceforge-v7-cache';
const ASSETS_TO_CACHE = [
  './',
  './index.html',
  'manifest.json',
  'https://cdn.tailwindcss.com'
];

// Install event: Cache essential files
self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE);
    }).catch(err => console.error('SW Cache Error:', err))
  );
});

// Activate event: Clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            return caches.delete(cache);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch event: Network-first, fallback to cache
self.addEventListener('fetch', (event) => {
  // Ignore non-GET requests and cross-origin APIs (like Sarvam/IndicF5)
  if (event.request.method !== 'GET' || !event.request.url.startsWith(self.location.origin)) {
    // Only cache tailwind CDN from cross-origin
    if (event.request.url.includes('cdn.tailwindcss.com')) {
      event.respondWith(
        caches.match(event.request).then(response => {
          return response || fetch(event.request).then(fetchRes => {
            return caches.open(CACHE_NAME).then(cache => {
              cache.put(event.request, fetchRes.clone());
              return fetchRes;
            });
          });
        })
      );
      return;
    }
    return; // Pass through to network
  }

  // Network-first strategy for local assets
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const resClone = response.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, resClone);
        });
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});